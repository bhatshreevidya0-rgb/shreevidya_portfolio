/**
 * SHREEVIDYA BHAT — PERSONAL DEVELOPER PORTFOLIO
 * Pure Vanilla JavaScript: Accessible, Fast, Zero Dependencies
 */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // --- 1. Theme Management (Light / Dark Theme) ---
  const themeToggleBtn = document.getElementById('theme-toggle');
  const htmlElement = document.documentElement;

  // Retrieve saved preference or default to 'light' per design requirements
  const savedTheme = localStorage.getItem('sb-portfolio-theme') || 'light';
  htmlElement.setAttribute('data-theme', savedTheme);

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const currentTheme = htmlElement.getAttribute('data-theme');
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      htmlElement.setAttribute('data-theme', newTheme);
      localStorage.setItem('sb-portfolio-theme', newTheme);
      showToast(`Switched to ${newTheme === 'dark' ? 'Dark' : 'Light'} theme`);
    });
  }

  // --- 2. Mobile Navigation Drawer ---
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const closeMobileNavBtn = document.getElementById('close-mobile-nav');
  const mobileNav = document.getElementById('mobile-nav');
  const drawerBackdrop = document.getElementById('drawer-backdrop');
  const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');
  const mobileResumeBtn = document.getElementById('mobile-resume-btn');

  function openMobileDrawer() {
    if (!mobileNav || !drawerBackdrop) return;
    mobileNav.classList.add('open');
    mobileNav.setAttribute('aria-hidden', 'false');
    drawerBackdrop.classList.add('active');
    if (mobileMenuBtn) {
      mobileMenuBtn.setAttribute('aria-expanded', 'true');
    }
    document.body.style.overflow = 'hidden';
  }

  function closeMobileDrawer() {
    if (!mobileNav || !drawerBackdrop) return;
    mobileNav.classList.remove('open');
    mobileNav.setAttribute('aria-hidden', 'true');
    drawerBackdrop.classList.remove('active');
    if (mobileMenuBtn) {
      mobileMenuBtn.setAttribute('aria-expanded', 'false');
    }
    document.body.style.overflow = '';
  }

  if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener('click', openMobileDrawer);
  }
  if (closeMobileNavBtn) {
    closeMobileNavBtn.addEventListener('click', closeMobileDrawer);
  }
  if (drawerBackdrop) {
    drawerBackdrop.addEventListener('click', closeMobileDrawer);
  }

  mobileNavLinks.forEach(link => {
    link.addEventListener('click', () => {
      closeMobileDrawer();
    });
  });

  if (mobileResumeBtn) {
    mobileResumeBtn.addEventListener('click', () => {
      closeMobileDrawer();
      openResumeModal();
    });
  }

  // --- 3. Sticky Navigation Active Link Spy ---
  const sections = document.querySelectorAll('section[id]');
  const desktopNavLinks = document.querySelectorAll('.desktop-nav .nav-link');

  function updateActiveNavLink() {
    const scrollPosition = window.scrollY + 120;

    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;
      const sectionId = section.getAttribute('id');

      if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
        desktopNavLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
          }
        });
      }
    });
  }

  window.addEventListener('scroll', updateActiveNavLink, { passive: true });

  // --- 4. Technical Skills Filter Tabs ---
  const skillTabs = document.querySelectorAll('.skills-filter-bar .filter-tab');
  const skillCards = document.querySelectorAll('.skills-categories-grid .skill-category-card');

  skillTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Toggle active tab style
      skillTabs.forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');

      const filterValue = tab.getAttribute('data-filter');

      skillCards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        if (filterValue === 'all' || cardCategory === filterValue) {
          card.style.display = 'flex';
          // Trigger subtle fade in
          card.style.opacity = '0';
          setTimeout(() => {
            card.style.transition = 'opacity 0.25s ease';
            card.style.opacity = '1';
          }, 10);
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // --- 5. Projects Filter Tabs ---
  const projectTabs = document.querySelectorAll('.project-tabs .project-tab');
  const projectCards = document.querySelectorAll('.projects-grid .project-card');

  projectTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      projectTabs.forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');

      const filterValue = tab.getAttribute('data-project-filter');

      projectCards.forEach(card => {
        const cardStatus = card.getAttribute('data-status');
        if (filterValue === 'all' || cardStatus === filterValue) {
          card.style.display = 'flex';
          card.style.opacity = '0';
          setTimeout(() => {
            card.style.transition = 'opacity 0.25s ease';
            card.style.opacity = '1';
          }, 10);
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // --- 6. Resume Modal Dialog ---
  const resumeModal = document.getElementById('resume-modal');
  const resumeBtn = document.getElementById('resume-btn');
  const heroResumeTrigger = document.getElementById('hero-resume-trigger');
  const closeResumeModalBtn = document.getElementById('close-resume-modal');
  const closeResumeModalFooterBtns = document.querySelectorAll('.close-resume-modal-btn');
  const printResumeBtn = document.getElementById('print-resume-btn');

  function openResumeModal() {
    if (!resumeModal) return;
    resumeModal.classList.add('open');
    resumeModal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeResumeModal() {
    if (!resumeModal) return;
    resumeModal.classList.remove('open');
    resumeModal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  if (resumeBtn) resumeBtn.addEventListener('click', openResumeModal);
  if (heroResumeTrigger) heroResumeTrigger.addEventListener('click', openResumeModal);
  if (closeResumeModalBtn) closeResumeModalBtn.addEventListener('click', closeResumeModal);
  closeResumeModalFooterBtns.forEach(btn => btn.addEventListener('click', closeResumeModal));

  if (printResumeBtn) {
    printResumeBtn.addEventListener('click', () => {
      window.print();
    });
  }

  // Close modal when clicking backdrop
  if (resumeModal) {
    resumeModal.addEventListener('click', (e) => {
      if (e.target === resumeModal) {
        closeResumeModal();
      }
    });
  }

  // --- 7. Project Details Modal (Plantmart) ---
  const projectModal = document.getElementById('project-modal');
  const openProjectModalBtns = document.querySelectorAll('.open-project-modal');
  const closeProjectModalBtn = document.getElementById('close-project-modal');
  const closeProjectModalFooterBtns = document.querySelectorAll('.close-project-modal-btn');

  function openProjectModal() {
    if (!projectModal) return;
    projectModal.classList.add('open');
    projectModal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeProjectModal() {
    if (!projectModal) return;
    projectModal.classList.remove('open');
    projectModal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  openProjectModalBtns.forEach(btn => {
    btn.addEventListener('click', openProjectModal);
  });

  if (closeProjectModalBtn) closeProjectModalBtn.addEventListener('click', closeProjectModal);
  closeProjectModalFooterBtns.forEach(btn => btn.addEventListener('click', closeProjectModal));

  if (projectModal) {
    projectModal.addEventListener('click', (e) => {
      if (e.target === projectModal) {
        closeProjectModal();
      }
    });
  }

  // --- 8. Global Keyboard ESC Listener for Modals & Drawer ---
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (resumeModal && resumeModal.classList.contains('open')) {
        closeResumeModal();
      }
      if (projectModal && projectModal.classList.contains('open')) {
        closeProjectModal();
      }
      if (mobileNav && mobileNav.classList.contains('open')) {
        closeMobileDrawer();
      }
    }
  });

  // --- 9. Clipboard Copy Functionality with Toast Feedback ---
  const copyButtons = document.querySelectorAll('[data-copy]');
  const toastElement = document.getElementById('toast');
  let toastTimeout;

  function showToast(message) {
    if (!toastElement) return;
    toastElement.textContent = message;
    toastElement.classList.add('show');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
      toastElement.classList.remove('show');
    }, 3200);
  }

  copyButtons.forEach(button => {
    button.addEventListener('click', async (e) => {
      e.preventDefault();
      const textToCopy = button.getAttribute('data-copy');
      if (!textToCopy) return;

      try {
        await navigator.clipboard.writeText(textToCopy);
        showToast(`Copied to clipboard: ${textToCopy}`);
      } catch (err) {
        // Fallback for older browsers
        const tempTextArea = document.createElement('textarea');
        tempTextArea.value = textToCopy;
        document.body.appendChild(tempTextArea);
        tempTextArea.select();
        document.execCommand('copy');
        document.body.removeChild(tempTextArea);
        showToast(`Copied to clipboard: ${textToCopy}`);
      }
    });
  });

  // --- 10. Interactive Contact Form with Validation & Mailto Action ---
  const contactForm = document.getElementById('contact-form');
  const nameInput = document.getElementById('contact-name');
  const emailInput = document.getElementById('contact-email');
  const subjectInput = document.getElementById('contact-subject');
  const messageInput = document.getElementById('contact-message');

  const nameError = document.getElementById('name-error');
  const emailError = document.getElementById('email-error');
  const subjectError = document.getElementById('subject-error');
  const messageError = document.getElementById('message-error');

  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  }

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      let isValid = true;

      // Validate Name
      if (!nameInput.value.trim()) {
        nameError.classList.add('show');
        isValid = false;
      } else {
        nameError.classList.remove('show');
      }

      // Validate Email
      if (!emailInput.value.trim() || !validateEmail(emailInput.value.trim())) {
        emailError.classList.add('show');
        isValid = false;
      } else {
        emailError.classList.remove('show');
      }

      // Validate Subject
      if (!subjectInput.value.trim()) {
        subjectError.classList.add('show');
        isValid = false;
      } else {
        subjectError.classList.remove('show');
      }

      // Validate Message
      if (!messageInput.value.trim() || messageInput.value.trim().length < 10) {
        messageError.classList.add('show');
        isValid = false;
      } else {
        messageError.classList.remove('show');
      }

      if (isValid) {
        const senderName = encodeURIComponent(nameInput.value.trim());
        const senderEmail = encodeURIComponent(emailInput.value.trim());
        const emailSubject = encodeURIComponent(`[Portfolio Inquiry] ${subjectInput.value.trim()} - from ${nameInput.value.trim()}`);
        const emailBody = encodeURIComponent(
          `Hello Shreevidya,\n\nName: ${nameInput.value.trim()}\nEmail: ${emailInput.value.trim()}\n\nMessage:\n${messageInput.value.trim()}\n\n---\nSent from your Portfolio Website.`
        );

        showToast('Opening your email client to send message...');
        
        // Launch mailto link after slight notification delay
        setTimeout(() => {
          window.location.href = `mailto:bhatshreevidya0@gmail.com?subject=${emailSubject}&body=${emailBody}`;
        }, 500);
      }
    });

    // Clear error on input
    [nameInput, emailInput, subjectInput, messageInput].forEach(input => {
      if (input) {
        input.addEventListener('input', () => {
          const errorSpan = document.getElementById(`${input.name}-error`);
          if (errorSpan) errorSpan.classList.remove('show');
        });
      }
    });
  }

  // --- 11. Back to Top Smooth Scroll Button ---
  const backToTopBtn = document.getElementById('back-to-top');
  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }

  // --- 12. Micro-Animation: Progress Meter Animation On Scroll ---
  const skillMeters = document.querySelectorAll('.skill-meter-fill');
  if ('IntersectionObserver' in window) {
    const meterObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const targetWidth = entry.target.style.width;
          entry.target.style.width = '0%';
          setTimeout(() => {
            entry.target.style.width = targetWidth;
          }, 150);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });

    skillMeters.forEach(meter => meterObserver.observe(meter));
  }
});
