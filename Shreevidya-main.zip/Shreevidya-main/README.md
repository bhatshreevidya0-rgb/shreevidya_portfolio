# Shreevidya Bhat — Developer Portfolio Website

A personal developer portfolio built for **Shreevidya Bhat**, first-year Master of Computer Applications (MCA) student at **Poornaprajna Institute of Management (PIM)**, Udupi, Karnataka.

## 🚀 Built With
- **Pure HTML5** (Semantic structure, WCAG 2.1 AA accessibility, JSON-LD Schema & OpenGraph metadata)
- **Vanilla CSS3** (Custom properties, Orange & Charcoal design system, Light & Dark themes, print stylesheet)
- **Vanilla JavaScript** (Zero external libraries, theme toggling, active scroll spy, mobile drawer, project/skills filter tabs, copy to clipboard, resume modal)

---

## 🎨 Design System & Palette
- **Primary Color:** Tech Orange (`#EA580C`, `#F97316`)
- **Base Neutral:** Charcoal (`#18181B`, `#27272A`, `#3F3F46`)
- **Default Appearance:** Light Theme (`#F8FAFC` background)
- **Dark Mode:** Deep Charcoal Theme with high-contrast text and warm orange accents
- **Typography:** Google Fonts *Plus Jakarta Sans* & *Space Grotesk*
- **Animation Policy:** Subtle micro-interactions, respecting `prefers-reduced-motion`

---

## 📂 Project Structure (Single Flat Root Directory)
```text
c:/Users/Dell/shreevidya/
├── index.html              # Main HTML markup & semantic sections
├── styles.css              # Custom CSS styles, themes, responsive breakpoints, print styles
├── script.js              # Vanilla JS for all interactive features & state
├── plantmart.jpg           # Real UI preview mockup for Plantmart e-commerce
└── README.md               # Documentation & running instructions
```

---

## 🌟 Key Features
1. **Text-Focused Hero Section:**
   - Highlights: "First-Year MCA Student" & "Poornaprajna Institute of Management (PIM)".
   - Location tag: 📍 Udupi, Karnataka.
   - Live availability badge: "Open for Internships & Collaborations".
   - Direct action buttons: Explore Work, Get in Touch, Curriculum Vitae modal.
   - Quick copy buttons for email (`bhatshreevidya0@gmail.com`) and phone (`7204358993`).

2. **Verified Technical Skills & Expertise:**
   - 100% faithful representation of verified self-assessed levels:
     - **Core Languages (Basic):** Python, PHP, Java, C, C++, C#, R
     - **Web Fundamentals (Basic):** HTML, CSS
     - **Query Languages (Basic):** SQL
     - **Frameworks & Databases:** ASP.NET, MySQL, Firebase, Object-Oriented Programming (OOP)
     - **Cloud & Tools:** AWS, Google Cloud, VS Code, GitHub, Generative AI Tools
   - Interactive category filter tabs (All Skills, Programming Languages, Web & Databases, Tools & Cloud).

3. **Featured Projects:**
   - **Plantmart — E-Commerce Website:**
     - Status: `Completed`
     - Overview: E-commerce platform eliminating manual buying.
     - Key Contribution: PHP backend architecture, database schemas, cart and checkout flow.
     - Tech Stack: PHP, MySQL, HTML5, CSS3.
     - Interactive "View Architecture & Details" modal with system specifications.
   - **Academic Data Analytics & Capstone Suite:**
     - Status: `In Planning / Upcoming` (adhering strictly to academic integrity guidelines).

4. **Certifications & State Honors:**
   - **Yuva AI for All** (National AI Literacy Certification, 2026).
   - **State Level Skit Winner** (Conferred by Karnataka Kalyana Samaja Elake, 2026, Ramayana story theatrical performance).

5. **Career Trajectory & Interests:**
   - Target Roles: Data Analyst, Software Developer, Web Developer, Backend Developer.
   - Long-Term Vision: Become a data analyst in a reputable company and make family proud.
   - Creative Interests: Dancing, Singing, Theater Skits.
   - Languages: English, Kannada.

6. **Interactive Curriculum Vitae (Resume Modal):**
   - Click "Resume" in the navbar or hero to launch a formatted, printable CV.
   - Dedicated `@media print` rules ensure clean, crisp 1-page PDF export via browser Print (`Ctrl + P`).

7. **Interactive Contact Section:**
   - Direct email and phone cards with instant copy-to-clipboard toast notifications.
   - Client-side validated contact form that launches pre-filled `mailto:` message.

---

## 💻 How to Run Locally
Run a lightweight HTTP server in the project folder:

```bash
# Using Python
python -m http.server 8080

# Or open index.html directly in any web browser:
start index.html
```

Then visit [http://localhost:8080](http://localhost:8080) in your web browser.
